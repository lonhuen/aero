#!/bin/sh
#if [[ $# != '0' ]]
#then
#        echo "usage: $0"
#        exit 1
#fi

GRAPHNAME=`basename $0 .sh`
EPS=graphs/$GRAPHNAME.eps
touch plot.plt

echo "
set terminal postscript eps 'Times-Roman,33' color size 7.2,4
set output 'graphs/$GRAPHNAME.eps'
set xrange [ 4096 : 65536]
set xtics nomirror font 'Times-Roman, 40' offset 0,-0.1
set nomxtics
set format x '2^{%L}'
set logscale x 2
set xlabel \"Number of users\" font 'Times-Roman,40'
set yrange [ 0.1 : 100000]
set ylabel \"Network upload (MiB)\\\n \" font 'Times-Roman, 40' offset -0.0,0.0
set ytics nomirror font 'Times-Roman, 40'
set nomytics
set logscale y 10
set grid noxtics noytics
#set grid ytics lw -1
set border 3 lw 4
set key top right maxrows 3
set bmargin 3.5
set pointsize 2.0
set style function linespoints
set style line 1 lw 4 lc rgb '#990042' ps 2 pt 6 pi 5
set style line 2 lw 3 lc rgb '#31f120' ps 2 pt 12 pi 3
set style line 3 lw 3 lc rgb '#0039a5' ps 2 pt 9 pi 5
set style line 4 lw 4 lc rgb '#888888' ps 2 pt 7 pi 4
set style line 6 lt 7 pt 14 lc rgb '#000000'
set style line 7 lt 7 pt 14 lc rgb '#736f6e'
set style line 1 lc rgb 'red'    dt 1 lw 7 lt 2 pt 64 ps 2.5 pi -1 
set style line 2 lc rgb 'blue'   dt 2 lw 7 lt 1 pt 1  ps 3 pi -1
set style line 3 lc rgb 'yellow' dt 3 lw 7 lt 7 pt 5  ps 2.5 pi -1
set style line 4 lc rgb 'brown'  dt 4 lw 7 lt 2 pt 65 ps 2.5 pi -1
set style line 5 lc rgb 'black'  dt 5 lw 7 lt 1 pt 2  ps 3   pi -1
set style line 1 lc rgb 'black' dt 1 lt 1 lw 7 pt 5 pi -1 ps 1.5
set style line 2 lc rgb 'red' dt 1 lt 1 lw 9 pt 7 pi -1 ps 3.0
set style line 3 lc rgb '#A9A9A9' dt 1 lt 1 lw 7 pt 6 pi -1 ps 3.0
set style line 4 lc rgb 'blue' dt 1 lt 1 lw 7 pt 8 pi -1 ps 2.0
set style line 5 lc rgb 'orange' dt 1 lt 1 lw 7 pt 10 pi -1 ps 3.0
set style line 1 lc rgb 'black' dt 1 lt 0 lw 6 pt 3 pi -1 ps 2.5
set style line 2 lc rgb 'black' dt 1 lt 1 lw 5 pt 5 pi -1 ps 1.25
set style line 3 lc rgb 'black' dt 1 lt 1 lw 7 pt 4 pi -1 ps 3.0
set style line 4 lc rgb 'orange' dt 1 lt 1 lw 9 pt 7 pi -1 ps 3.5
set style line 5 lc rgb 'orange' dt 1 lt 1 lw 7 pt 6 pi -1 ps 3.0
set style line 6 lc rgb 'blue' dt 1 lt 1 lw 7 pt 9 pi -1 ps 3.5
set style line 7 lc rgb 'blue' dt 1 lt 1 lw 7 pt 8 pi -1 ps 3.5
plot \
'dat/client_network_upload.dat' using 1:(\$2/1048576) with linespoints ls 3 title 'Addra',\
'dat/client_network_upload.dat' using 1:(\$3/1048576) with linespoints ls 4 title 'P-XPIR (d=1)',\
'dat/client_network_upload.dat' using 1:(\$4/1048576) with linespoints ls 5 title 'P-XPIR (d=2)',\
'dat/client_network_upload.dat' using 1:(\$5/1048576) with linespoints ls 6 title 'P-SPIR (d=1)',\
'dat/client_network_upload.dat' using 1:(\$6/1048576) with linespoints ls 7 title 'P-SPIR (d=2)'
" > plot.plt
gnuplot plot.plt
epspdf $EPS
rm $EPS
