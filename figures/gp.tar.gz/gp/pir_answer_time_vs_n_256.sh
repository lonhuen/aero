#!/bin/sh
#if [[ $# != '0' ]]
#then
#        echo "usage: $0"
#        exit 1
#fi

GRAPHNAME=`basename $0 .sh`
EPS=graphs/$GRAPHNAME.eps
touch plot.plt

echo "
set terminal postscript eps 'Times-Roman,30' color size 6.3,4
set output 'graphs/$GRAPHNAME.eps'
set xrange [ 8192 : 1048576]
set xtics nomirror font 'Times-Roman, 38' offset 0,-0.1
set nomxtics
set format x '2^{%L}'
set logscale x 2
set xlabel \"Number of messages (n)\\\\n \\\n Message size (m) = 256 bytes\" font 'Times-Roman,38'
set yrange [ 1 : 10000]
set ylabel \"Reply gen. time (ms)\\\n \\\\n \" font 'Times-Roman,38' offset -0.0,0.0
set ytics nomirror font 'Times-Roman, 38'
set nomytics
set format y '10^{%T}'
set logscale y 10
set grid noxtics noytics
set border 3 lw 4
set key bottom left horizontal samplen 2.5 width 0.2 font 'Times-Roman,31'
set bmargin 5.5
set rmargin 4.5
set pointsize 2.0
#set size 1.75,1.25
set style function linespoints
#set style line 1 lw 4 lc rgb '#990042' ps 2 pt 6 pi 5
#set style line 2 lw 3 lc rgb '#31f120' ps 2 pt 12 pi 3
#set style line 3 lw 3 lc rgb '#0038a5' ps 2 pt 9 pi 5
#set style line 4 lw 4 lc rgb '#888888' ps 2 pt 7 pi 4
#set style line 6 lt 7 pt 14 lc rgb '#000000'
#set style line 7 lt 7 pt 14 lc rgb '#736f6e'
#set style line 1 lc rgb 'red'    dt 1 lw 7 lt 2 pt 64 ps 2.5 pi -1 
#set style line 2 lc rgb 'blue'   dt 2 lw 7 lt 1 pt 1  ps 3 pi -1
#set style line 3 lc rgb 'yellow' dt 3 lw 7 lt 7 pt 5  ps 2.5 pi -1
#set style line 4 lc rgb 'brown'  dt 4 lw 7 lt 2 pt 65 ps 2.5 pi -1
#set style line 5 lc rgb 'black'  dt 5 lw 7 lt 1 pt 2  ps 3   pi -1
set style line 1 lc rgb 'black' dt 1 lt 0 lw 6 pt 3 pi -1 ps 2.5
set style line 2 lc rgb 'black' dt 1 lt 1 lw 5 pt 5 pi -1 ps 1.25
set style line 3 lc rgb 'black' dt 1 lt 1 lw 7 pt 4 pi -1 ps 1.5
set style line 4 lc rgb 'orange' dt 1 lt 1 lw 9 pt 7 pi -1 ps 2.0
set style line 5 lc rgb 'orange' dt 1 lt 1 lw 7 pt 6 pi -1 ps 2.0
set style line 6 lc rgb 'blue' dt 1 lt 1 lw 7 pt 9 pi -1 ps 3.5
set style line 7 lc rgb 'blue' dt 1 lt 1 lw 7 pt 8 pi -1 ps 2.5
#set style line 7 lc rgb 'orange' dt 1 lt 1 lw 7 pt 10 pi -1 ps 3.0
plot \
'dat/pir_answer_time_256.dat' using 1:(\$2) with linespoints ls 1 title 'F-1',\
'dat/pir_answer_time_256.dat' using 1:(\$3) with linespoints ls 2 title 'F-2',\
'dat/pir_answer_time_256.dat' using 1:(\$4) with linespoints ls 3 title 'F',\
'dat/pir_answer_time_256.dat' using 1:(\$5) with linespoints ls 4 title 'X (d=1)',\
'dat/pir_answer_time_256.dat' using 1:(\$6) with linespoints ls 5 title 'X (d=2)',\
'dat/pir_answer_time_256.dat' using 1:(\$7) with linespoints ls 6 title 'S (d=1)',\
'dat/pir_answer_time_256.dat' using 1:(\$8) with linespoints ls 7 title 'S (d=2)'
" > plot.plt
gnuplot plot.plt
epspdf $EPS
rm $EPS
